from django.contrib import admin
from .models import Detail
# Register your models here.

admin.site.register(Detail)