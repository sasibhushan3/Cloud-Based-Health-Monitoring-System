from django.apps import AppConfig


class HealthCheckupConfig(AppConfig):
    name = 'health_checkup'
